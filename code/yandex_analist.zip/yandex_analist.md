# Описание проекта

<div style="border:solid blue 2px; padding: 20px"> 
    

Вы работаете в интернет-магазине «Стримчик», который продаёт по всему миру компьютерные игры. Из открытых источников доступны исторические данные о продажах игр, оценки пользователей и экспертов, жанры и платформы (например, Xbox или PlayStation). Вам нужно выявить определяющие успешность игры закономерности. Это позволит сделать ставку на потенциально популярный продукт и спланировать рекламные кампании.
    
    
Перед вами данные до 2016 года. Представим, что сейчас декабрь 2016 г., и вы планируете кампанию на 2017-й. Нужно отработать принцип работы с данными. Не важно, прогнозируете ли вы продажи на 2017 год по данным 2016-го или же 2027-й — по данным 2026 года.
    
    
<b>Описание данных games.csv</b>
    
- Name — название игры
    
- Platform — платформа
    
- Year_of_Release — год выпуска
    
- Genre — жанр игры
    
- NA_sales — продажи в Северной Америке (миллионы долларов)
    
- EU_sales — продажи в Европе (миллионы долларов)
    
- JP_sales — продажи в Японии (миллионы долларов)
    
- Other_sales — продажи в других странах (миллионы долларов)
    
- Critic_Score — оценка критиков (от 0 до 100)
    
- User_Score — оценка пользователей (от 0 до 10)
    
- Rating — рейтинг от организации ESRB (англ. Entertainment Software Rating Board). Эта ассоциация определяет рейтинг компьютерных игр и присваивает им подходящую возрастную категорию.
    
    
Данные за 2016 год могут быть неполными.
    
</div>

# Шаг 2. Откройте файл с данными и изучите общую информацию


```python
import pandas as pd
import copy
import numpy as np
import scipy.stats as st
import matplotlib.pyplot as plt
import seaborn as sns
from datetime import datetime # импортирую все необходимые библиотеки сразу
df = pd.read_csv('/games.csv')
df.info()
```

    <class 'pandas.core.frame.DataFrame'>
    RangeIndex: 16715 entries, 0 to 16714
    Data columns (total 11 columns):
     #   Column           Non-Null Count  Dtype  
    ---  ------           --------------  -----  
     0   Name             16713 non-null  object 
     1   Platform         16715 non-null  object 
     2   Year_of_Release  16446 non-null  float64
     3   Genre            16713 non-null  object 
     4   NA_sales         16715 non-null  float64
     5   EU_sales         16715 non-null  float64
     6   JP_sales         16715 non-null  float64
     7   Other_sales      16715 non-null  float64
     8   Critic_Score     8137 non-null   float64
     9   User_Score       10014 non-null  object 
     10  Rating           9949 non-null   object 
    dtypes: float64(6), object(5)
    memory usage: 1.4+ MB
    


```python
df
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Name</th>
      <th>Platform</th>
      <th>Year_of_Release</th>
      <th>Genre</th>
      <th>NA_sales</th>
      <th>EU_sales</th>
      <th>JP_sales</th>
      <th>Other_sales</th>
      <th>Critic_Score</th>
      <th>User_Score</th>
      <th>Rating</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>Wii Sports</td>
      <td>Wii</td>
      <td>2006.0</td>
      <td>Sports</td>
      <td>41.36</td>
      <td>28.96</td>
      <td>3.77</td>
      <td>8.45</td>
      <td>76.0</td>
      <td>8</td>
      <td>E</td>
    </tr>
    <tr>
      <th>1</th>
      <td>Super Mario Bros.</td>
      <td>NES</td>
      <td>1985.0</td>
      <td>Platform</td>
      <td>29.08</td>
      <td>3.58</td>
      <td>6.81</td>
      <td>0.77</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>2</th>
      <td>Mario Kart Wii</td>
      <td>Wii</td>
      <td>2008.0</td>
      <td>Racing</td>
      <td>15.68</td>
      <td>12.76</td>
      <td>3.79</td>
      <td>3.29</td>
      <td>82.0</td>
      <td>8.3</td>
      <td>E</td>
    </tr>
    <tr>
      <th>3</th>
      <td>Wii Sports Resort</td>
      <td>Wii</td>
      <td>2009.0</td>
      <td>Sports</td>
      <td>15.61</td>
      <td>10.93</td>
      <td>3.28</td>
      <td>2.95</td>
      <td>80.0</td>
      <td>8</td>
      <td>E</td>
    </tr>
    <tr>
      <th>4</th>
      <td>Pokemon Red/Pokemon Blue</td>
      <td>GB</td>
      <td>1996.0</td>
      <td>Role-Playing</td>
      <td>11.27</td>
      <td>8.89</td>
      <td>10.22</td>
      <td>1.00</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <th>16710</th>
      <td>Samurai Warriors: Sanada Maru</td>
      <td>PS3</td>
      <td>2016.0</td>
      <td>Action</td>
      <td>0.00</td>
      <td>0.00</td>
      <td>0.01</td>
      <td>0.00</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>16711</th>
      <td>LMA Manager 2007</td>
      <td>X360</td>
      <td>2006.0</td>
      <td>Sports</td>
      <td>0.00</td>
      <td>0.01</td>
      <td>0.00</td>
      <td>0.00</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>16712</th>
      <td>Haitaka no Psychedelica</td>
      <td>PSV</td>
      <td>2016.0</td>
      <td>Adventure</td>
      <td>0.00</td>
      <td>0.00</td>
      <td>0.01</td>
      <td>0.00</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>16713</th>
      <td>Spirits &amp; Spells</td>
      <td>GBA</td>
      <td>2003.0</td>
      <td>Platform</td>
      <td>0.01</td>
      <td>0.00</td>
      <td>0.00</td>
      <td>0.00</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>16714</th>
      <td>Winning Post 8 2016</td>
      <td>PSV</td>
      <td>2016.0</td>
      <td>Simulation</td>
      <td>0.00</td>
      <td>0.00</td>
      <td>0.01</td>
      <td>0.00</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
  </tbody>
</table>
<p>16715 rows × 11 columns</p>
</div>



Проверяю данные в каждом столбце. Основательно изучаю столбцы, где есть пропуски.


```python
def check_columns(df):
    for column in df:
        print(column)
        print(df[column].unique())
check_columns(df)
```

    Name
    ['Wii Sports' 'Super Mario Bros.' 'Mario Kart Wii' ...
     'Woody Woodpecker in Crazy Castle 5' 'LMA Manager 2007'
     'Haitaka no Psychedelica']
    Platform
    ['Wii' 'NES' 'GB' 'DS' 'X360' 'PS3' 'PS2' 'SNES' 'GBA' 'PS4' '3DS' 'N64'
     'PS' 'XB' 'PC' '2600' 'PSP' 'XOne' 'WiiU' 'GC' 'GEN' 'DC' 'PSV' 'SAT'
     'SCD' 'WS' 'NG' 'TG16' '3DO' 'GG' 'PCFX']
    Year_of_Release
    [2006. 1985. 2008. 2009. 1996. 1989. 1984. 2005. 1999. 2007. 2010. 2013.
     2004. 1990. 1988. 2002. 2001. 2011. 1998. 2015. 2012. 2014. 1992. 1997.
     1993. 1994. 1982. 2016. 2003. 1986. 2000.   nan 1995. 1991. 1981. 1987.
     1980. 1983.]
    Genre
    ['Sports' 'Platform' 'Racing' 'Role-Playing' 'Puzzle' 'Misc' 'Shooter'
     'Simulation' 'Action' 'Fighting' 'Adventure' 'Strategy' nan]
    NA_sales
    [4.136e+01 2.908e+01 1.568e+01 1.561e+01 1.127e+01 2.320e+01 1.128e+01
     1.396e+01 1.444e+01 2.693e+01 9.050e+00 9.710e+00 9.000e+00 8.920e+00
     1.500e+01 9.010e+00 7.020e+00 9.430e+00 1.278e+01 4.740e+00 6.380e+00
     1.083e+01 9.540e+00 9.660e+00 8.410e+00 6.060e+00 3.430e+00 5.510e+00
     6.850e+00 9.040e+00 5.890e+00 6.030e+00 9.700e+00 5.280e+00 4.990e+00
     8.250e+00 8.520e+00 5.540e+00 6.990e+00 6.620e+00 5.030e+00 5.990e+00
     3.960e+00 2.500e+00 7.970e+00 6.910e+00 4.340e+00 4.350e+00 3.010e+00
     6.160e+00 6.760e+00 4.020e+00 4.890e+00 2.960e+00 4.760e+00 5.010e+00
     6.730e+00 5.950e+00 3.660e+00 5.550e+00 7.040e+00 6.650e+00 3.880e+00
     5.800e+00 4.100e+00 5.930e+00 4.360e+00 5.700e+00 2.030e+00 4.400e+00
     5.050e+00 3.540e+00 1.120e+00 6.820e+00 1.750e+00 3.740e+00 1.060e+00
     2.790e+00 2.910e+00 9.900e-01 2.570e+00 2.990e+00 2.280e+00 7.280e+00
     2.760e+00 2.900e+00 2.810e+00 6.600e-01 3.780e+00 3.270e+00 3.560e+00
     5.390e+00 4.590e+00 4.810e+00 4.460e+00 3.480e+00 2.850e+00 2.530e+00
     2.980e+00 3.680e+00 3.150e+00 4.410e+00 4.120e+00 2.710e+00 2.930e+00
     3.230e+00 4.050e+00 4.150e+00 2.770e+00 3.450e+00 3.110e+00 8.400e-01
     1.660e+00 7.800e-01 2.640e+00 3.170e+00 4.980e+00 2.550e+00 3.640e+00
     3.700e+00 4.010e+00 2.470e+00 8.000e-02 3.920e+00 8.000e-01 2.450e+00
     4.470e+00 3.180e+00 2.630e+00 1.880e+00 2.410e+00 2.800e+00 6.300e-01
     2.260e+00 2.490e+00 3.570e+00 3.070e+00 2.970e+00 2.950e+00 2.540e+00
     3.280e+00 3.140e+00 4.700e-01 2.620e+00 3.210e+00 2.070e+00 2.730e+00
     1.850e+00 2.180e+00 1.740e+00 3.020e+00 1.620e+00 3.130e+00 1.920e+00
     3.330e+00 3.220e+00 2.300e+00 4.260e+00 9.700e-01 6.500e-01 1.210e+00
     1.090e+00 2.100e+00 2.440e+00 1.980e+00 3.810e+00 3.590e+00 1.630e+00
     1.960e+00 3.400e+00 6.100e-01 2.050e+00 1.700e+00 3.420e+00 3.360e+00
     3.490e+00 3.050e+00 1.830e+00 2.310e+00 3.980e+00 0.000e+00 2.600e+00
     1.910e+00 2.740e+00 2.830e+00 2.360e+00 1.730e+00 1.940e+00 2.290e+00
     1.820e+00 2.420e+00 3.040e+00 1.800e+00 2.080e+00 1.870e+00 4.180e+00
     3.190e+00 4.210e+00 3.630e+00 2.780e+00 2.000e-01 1.610e+00 1.540e+00
     2.520e+00 2.660e+00 1.000e-01 2.820e+00 2.190e+00 1.560e+00 3.030e+00
     2.200e+00 2.090e+00 2.110e+00 1.480e+00 4.000e+00 5.800e-01 2.510e+00
     3.000e+00 2.240e+00 1.460e+00 1.410e+00 9.200e-01 8.800e-01 1.280e+00
     2.250e+00 3.380e+00 2.040e+00 3.790e+00 4.030e+00 1.650e+00 7.100e-01
     1.420e+00 1.100e+00 2.320e+00 1.200e-01 2.350e+00 2.120e+00 1.400e+00
     1.680e+00 1.130e+00 1.220e+00 2.670e+00 1.020e+00 1.190e+00 1.530e+00
     2.150e+00 9.000e-01 1.970e+00 6.800e-01 1.160e+00 9.300e-01 1.440e+00
     1.600e-01 2.130e+00 2.210e+00 1.780e+00 8.600e-01 1.350e+00 1.050e+00
     2.230e+00 2.400e+00 1.370e+00 1.300e+00 1.950e+00 1.930e+00 1.330e+00
     1.490e+00 1.580e+00 5.000e-02 6.000e-01 2.020e+00 2.380e+00 1.600e+00
     2.010e+00 1.570e+00 1.230e+00 1.900e+00 2.140e+00 1.170e+00 2.270e+00
     1.640e+00 5.900e-01 1.550e+00 4.600e-01 8.100e-01 1.450e+00 2.700e-01
     1.470e+00 1.990e+00 1.500e+00 9.000e-02 2.610e+00 1.890e+00 5.000e-01
     8.900e-01 9.500e-01 2.340e+00 7.200e-01 1.720e+00 1.180e+00 1.760e+00
     7.300e-01 1.270e+00 2.060e+00 5.500e-01 1.520e+00 1.690e+00 2.170e+00
     5.100e-01 1.000e+00 1.290e+00 1.380e+00 1.150e+00 1.670e+00 1.360e+00
     1.010e+00 1.040e+00 1.840e+00 2.220e+00 7.900e-01 1.510e+00 1.070e+00
     1.320e+00 1.590e+00 2.000e-02 2.900e-01 1.250e+00 2.560e+00 1.430e+00
     1.200e+00 4.100e-01 2.800e-01 4.300e-01 6.900e-01 2.000e+00 7.600e-01
     1.860e+00 4.800e-01 6.200e-01 1.310e+00 3.700e-01 1.500e-01 6.400e-01
     2.600e-01 4.900e-01 1.110e+00 1.300e-01 1.810e+00 1.030e+00 1.260e+00
     8.700e-01 7.700e-01 9.600e-01 1.390e+00 1.080e+00 8.500e-01 9.100e-01
     3.000e-01 3.800e-01 9.400e-01 7.000e-02 1.340e+00 1.240e+00 3.400e-01
     1.400e-01 1.000e-02 5.200e-01 8.200e-01 8.300e-01 1.100e-01 2.500e-01
     1.770e+00 3.600e-01 7.500e-01 7.400e-01 1.800e-01 2.200e-01 5.300e-01
     4.200e-01 3.200e-01 3.900e-01 2.400e-01 2.300e-01 6.000e-02 4.500e-01
     7.000e-01 6.700e-01 3.500e-01 5.600e-01 1.140e+00 9.800e-01 5.700e-01
     5.400e-01 4.000e-02 1.700e-01 4.400e-01 3.000e-02 3.300e-01 3.100e-01
     4.000e-01 2.100e-01 1.900e-01]
    EU_sales
    [2.896e+01 3.580e+00 1.276e+01 1.093e+01 8.890e+00 2.260e+00 9.140e+00
     9.180e+00 6.940e+00 6.300e-01 1.095e+01 7.470e+00 6.180e+00 8.030e+00
     4.890e+00 8.490e+00 9.090e+00 4.000e-01 3.750e+00 9.200e+00 4.460e+00
     2.710e+00 3.440e+00 5.140e+00 5.490e+00 3.900e+00 5.350e+00 3.170e+00
     5.090e+00 4.240e+00 5.040e+00 5.860e+00 3.680e+00 4.190e+00 5.730e+00
     3.590e+00 4.510e+00 2.550e+00 4.020e+00 4.370e+00 6.310e+00 3.450e+00
     2.810e+00 2.850e+00 3.490e+00 1.000e-02 3.350e+00 2.040e+00 3.070e+00
     3.870e+00 3.000e+00 4.820e+00 3.640e+00 2.150e+00 3.690e+00 2.650e+00
     2.560e+00 3.110e+00 3.140e+00 1.940e+00 1.950e+00 2.470e+00 2.280e+00
     3.420e+00 3.630e+00 2.360e+00 1.710e+00 1.850e+00 2.790e+00 1.240e+00
     6.120e+00 1.530e+00 3.470e+00 2.240e+00 5.010e+00 2.010e+00 1.720e+00
     2.070e+00 6.420e+00 3.860e+00 4.500e-01 3.480e+00 1.890e+00 5.750e+00
     2.170e+00 1.370e+00 2.350e+00 1.180e+00 2.110e+00 1.880e+00 2.830e+00
     2.990e+00 2.890e+00 3.270e+00 2.220e+00 2.140e+00 1.450e+00 1.750e+00
     1.040e+00 1.770e+00 3.020e+00 2.750e+00 2.160e+00 1.900e+00 2.590e+00
     2.200e+00 4.300e+00 9.300e-01 2.530e+00 2.520e+00 1.790e+00 1.300e+00
     2.600e+00 1.580e+00 1.200e+00 1.560e+00 1.340e+00 1.260e+00 8.300e-01
     6.210e+00 2.800e+00 1.590e+00 1.730e+00 4.330e+00 1.830e+00 0.000e+00
     2.180e+00 1.980e+00 1.470e+00 6.700e-01 1.550e+00 1.910e+00 6.900e-01
     6.000e-01 1.930e+00 1.640e+00 5.500e-01 2.190e+00 1.110e+00 2.290e+00
     2.500e+00 9.600e-01 1.210e+00 1.120e+00 7.700e-01 1.690e+00 1.080e+00
     7.900e-01 2.370e+00 2.460e+00 2.600e-01 7.500e-01 1.250e+00 2.430e+00
     9.800e-01 7.400e-01 2.230e+00 6.100e-01 2.450e+00 1.410e+00 1.800e+00
     3.280e+00 1.160e+00 1.990e+00 1.380e+00 1.360e+00 1.170e+00 1.190e+00
     9.900e-01 1.680e+00 2.000e+00 1.330e+00 1.570e+00 1.480e+00 2.100e+00
     1.270e+00 1.970e+00 9.100e-01 1.390e+00 1.960e+00 2.400e-01 1.510e+00
     1.400e-01 1.290e+00 2.390e+00 1.030e+00 5.000e-01 5.800e-01 1.310e+00
     2.020e+00 1.320e+00 1.010e+00 2.270e+00 2.300e+00 1.820e+00 2.780e+00
     4.400e-01 4.800e-01 2.700e-01 2.100e-01 2.480e+00 5.100e-01 1.520e+00
     4.000e-02 2.800e-01 1.350e+00 8.700e-01 2.130e+00 1.130e+00 1.760e+00
     7.600e-01 2.120e+00 6.600e-01 1.600e+00 1.440e+00 1.430e+00 1.700e+00
     4.700e-01 1.870e+00 8.600e-01 7.300e-01 1.280e+00 8.100e-01 1.090e+00
     6.800e-01 1.220e+00 1.400e+00 1.020e+00 1.490e+00 1.140e+00 4.900e-01
     9.000e-01 3.800e-01 1.420e+00 9.500e-01 1.620e+00 7.100e-01 1.050e+00
     9.200e-01 3.300e-01 3.000e-01 1.670e+00 1.000e+00 8.900e-01 1.000e-01
     7.200e-01 5.900e-01 5.600e-01 1.600e-01 9.700e-01 6.200e-01 8.500e-01
     9.400e-01 8.800e-01 8.400e-01 1.060e+00 2.000e-01 1.150e+00 8.000e-01
     1.100e+00 7.000e-01 1.920e+00 3.200e-01 1.500e-01 5.300e-01 9.000e-02
     1.460e+00 2.900e-01 2.200e-01 1.230e+00 7.000e-02 1.700e-01 5.400e-01
     3.600e-01 3.100e-01 1.840e+00 5.200e-01 1.100e-01 6.400e-01 1.200e-01
     2.050e+00 1.630e+00 8.200e-01 8.000e-02 5.700e-01 1.650e+00 1.900e-01
     2.000e-02 4.300e-01 2.500e-01 1.500e+00 1.800e-01 3.900e-01 1.300e-01
     1.070e+00 4.600e-01 4.100e-01 6.000e-02 3.000e-02 3.700e-01 5.000e-02
     2.300e-01 6.500e-01 4.200e-01 3.400e-01 3.500e-01 7.800e-01]
    JP_sales
    [3.770e+00 6.810e+00 3.790e+00 3.280e+00 1.022e+01 4.220e+00 6.500e+00
     2.930e+00 4.700e+00 2.800e-01 1.930e+00 4.130e+00 7.200e+00 3.600e+00
     2.400e-01 2.530e+00 9.800e-01 4.100e-01 3.540e+00 4.160e+00 6.040e+00
     4.180e+00 3.840e+00 6.000e-02 4.700e-01 5.380e+00 5.320e+00 5.650e+00
     1.870e+00 1.300e-01 3.120e+00 3.600e-01 1.100e-01 4.350e+00 6.500e-01
     7.000e-02 8.000e-02 4.900e-01 3.000e-01 2.660e+00 2.690e+00 4.800e-01
     3.800e-01 5.330e+00 1.910e+00 3.960e+00 3.100e+00 1.100e+00 1.200e+00
     1.400e-01 2.540e+00 2.140e+00 8.100e-01 2.120e+00 4.400e-01 3.150e+00
     1.250e+00 4.000e-02 0.000e+00 2.470e+00 2.230e+00 1.690e+00 1.000e-02
     3.000e+00 2.000e-02 4.390e+00 1.980e+00 1.000e-01 3.810e+00 5.000e-02
     2.490e+00 1.580e+00 3.140e+00 2.730e+00 6.600e-01 2.200e-01 3.630e+00
     1.450e+00 1.310e+00 2.430e+00 7.000e-01 3.500e-01 1.400e+00 6.000e-01
     2.260e+00 1.420e+00 1.280e+00 1.390e+00 8.700e-01 1.700e-01 9.400e-01
     1.900e-01 2.100e-01 1.600e+00 1.600e-01 1.030e+00 2.500e-01 2.060e+00
     1.490e+00 1.290e+00 9.000e-02 2.870e+00 3.000e-02 7.800e-01 8.300e-01
     2.330e+00 2.020e+00 1.360e+00 1.810e+00 1.970e+00 9.100e-01 9.900e-01
     9.500e-01 2.000e+00 1.010e+00 2.780e+00 2.110e+00 1.090e+00 2.000e-01
     1.900e+00 1.270e+00 3.610e+00 1.570e+00 2.200e+00 1.700e+00 1.080e+00
     1.500e-01 1.110e+00 2.900e-01 1.540e+00 1.200e-01 8.900e-01 4.870e+00
     1.520e+00 1.320e+00 1.150e+00 4.100e+00 1.460e+00 4.600e-01 1.050e+00
     1.610e+00 2.600e-01 1.380e+00 6.200e-01 7.300e-01 5.700e-01 3.100e-01
     5.800e-01 1.760e+00 2.100e+00 9.000e-01 5.100e-01 6.400e-01 2.460e+00
     2.300e-01 3.700e-01 9.200e-01 1.070e+00 2.620e+00 1.120e+00 5.400e-01
     2.700e-01 5.900e-01 3.670e+00 5.500e-01 1.750e+00 3.440e+00 3.300e-01
     2.550e+00 2.320e+00 2.790e+00 7.400e-01 3.180e+00 8.200e-01 7.700e-01
     4.000e-01 2.350e+00 3.190e+00 8.000e-01 7.600e-01 3.030e+00 8.800e-01
     4.500e-01 1.160e+00 3.400e-01 1.190e+00 1.130e+00 2.130e+00 1.960e+00
     7.100e-01 1.040e+00 2.680e+00 6.800e-01 2.650e+00 9.600e-01 2.410e+00
     5.200e-01 1.800e-01 1.340e+00 1.480e+00 2.340e+00 1.060e+00 1.210e+00
     2.290e+00 1.630e+00 2.050e+00 2.170e+00 1.560e+00 1.350e+00 1.330e+00
     6.300e-01 7.900e-01 7.500e-01 5.300e-01 1.530e+00 1.300e+00 3.900e-01
     6.900e-01 4.200e-01 9.300e-01 5.600e-01 8.400e-01 7.200e-01 3.200e-01
     1.710e+00 1.650e+00 6.100e-01 1.510e+00 1.500e+00 1.440e+00 1.240e+00
     1.180e+00 1.370e+00 1.000e+00 1.260e+00 8.500e-01 4.300e-01 6.700e-01
     1.140e+00 8.600e-01 1.170e+00 5.000e-01 1.020e+00 9.700e-01]
    Other_sales
    [8.450e+00 7.700e-01 3.290e+00 2.950e+00 1.000e+00 5.800e-01 2.880e+00
     2.840e+00 2.240e+00 4.700e-01 2.740e+00 1.900e+00 7.100e-01 2.150e+00
     1.690e+00 1.770e+00 3.960e+00 1.057e+01 5.500e-01 2.040e+00 1.360e+00
     4.200e-01 4.600e-01 1.410e+00 1.780e+00 5.000e-01 1.180e+00 8.000e-01
     1.160e+00 1.320e+00 5.900e-01 2.380e+00 1.130e+00 7.800e-01 2.420e+00
     1.120e+00 1.280e+00 1.570e+00 1.300e+00 1.010e+00 9.100e-01 1.790e+00
     1.970e+00 8.600e-01 1.210e+00 2.300e-01 7.600e-01 7.400e-01 7.530e+00
     2.900e-01 1.030e+00 5.200e-01 2.110e+00 1.600e+00 1.610e+00 3.500e-01
     9.700e-01 1.060e+00 6.300e-01 1.500e-01 7.900e-01 9.600e-01 1.250e+00
     9.000e-01 8.100e-01 3.900e-01 6.800e-01 8.500e-01 1.800e-01 8.000e-02
     6.700e-01 7.000e-01 4.100e-01 3.300e-01 6.000e-01 5.400e-01 1.730e+00
     1.230e+00 1.600e-01 1.110e+00 3.100e-01 4.800e-01 6.200e-01 1.900e-01
     6.900e-01 1.020e+00 7.300e-01 1.080e+00 4.500e-01 2.800e-01 5.100e-01
     2.200e-01 1.090e+00 9.900e-01 3.000e-01 6.400e-01 6.600e-01 9.800e-01
     1.390e+00 1.400e-01 1.370e+00 7.000e-02 2.100e-01 6.100e-01 1.700e-01
     1.200e-01 0.000e+00 7.200e-01 2.400e-01 8.200e-01 1.740e+00 8.700e-01
     9.200e-01 5.700e-01 1.100e-01 4.000e-02 5.600e-01 2.000e-01 3.400e-01
     9.000e-02 8.300e-01 4.400e-01 6.000e-02 3.200e-01 3.800e-01 1.480e+00
     3.700e-01 1.000e-01 2.500e-01 3.600e-01 1.300e-01 4.300e-01 5.000e-02
     2.000e-02 2.600e-01 4.000e-01 7.500e-01 1.930e+00 8.400e-01 5.300e-01
     8.900e-01 1.670e+00 2.700e-01 2.930e+00 4.900e-01 1.000e-02 2.460e+00
     3.000e-02 1.510e+00 2.050e+00 1.680e+00 1.820e+00 1.330e+00 9.400e-01
     9.300e-01]
    Critic_Score
    [76. nan 82. 80. 89. 58. 87. 91. 61. 97. 95. 77. 88. 83. 94. 93. 85. 86.
     98. 96. 90. 84. 73. 74. 78. 92. 71. 72. 68. 62. 49. 67. 81. 66. 56. 79.
     70. 59. 64. 75. 60. 63. 69. 50. 25. 42. 44. 55. 48. 57. 29. 47. 65. 54.
     20. 53. 37. 38. 33. 52. 30. 32. 43. 45. 51. 40. 46. 39. 34. 35. 41. 36.
     28. 31. 27. 26. 19. 23. 24. 21. 17. 22. 13.]
    User_Score
    ['8' nan '8.3' '8.5' '6.6' '8.4' '8.6' '7.7' '6.3' '7.4' '8.2' '9' '7.9'
     '8.1' '8.7' '7.1' '3.4' '5.3' '4.8' '3.2' '8.9' '6.4' '7.8' '7.5' '2.6'
     '7.2' '9.2' '7' '7.3' '4.3' '7.6' '5.7' '5' '9.1' '6.5' 'tbd' '8.8' '6.9'
     '9.4' '6.8' '6.1' '6.7' '5.4' '4' '4.9' '4.5' '9.3' '6.2' '4.2' '6' '3.7'
     '4.1' '5.8' '5.6' '5.5' '4.4' '4.6' '5.9' '3.9' '3.1' '2.9' '5.2' '3.3'
     '4.7' '5.1' '3.5' '2.5' '1.9' '3' '2.7' '2.2' '2' '9.5' '2.1' '3.6' '2.8'
     '1.8' '3.8' '0' '1.6' '9.6' '2.4' '1.7' '1.1' '0.3' '1.5' '0.7' '1.2'
     '2.3' '0.5' '1.3' '0.2' '0.6' '1.4' '0.9' '1' '9.7']
    Rating
    ['E' nan 'M' 'T' 'E10+' 'K-A' 'AO' 'EC' 'RP']
    


```python
df[df['Name'].isna()]
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Name</th>
      <th>Platform</th>
      <th>Year_of_Release</th>
      <th>Genre</th>
      <th>NA_sales</th>
      <th>EU_sales</th>
      <th>JP_sales</th>
      <th>Other_sales</th>
      <th>Critic_Score</th>
      <th>User_Score</th>
      <th>Rating</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>659</th>
      <td>NaN</td>
      <td>GEN</td>
      <td>1993.0</td>
      <td>NaN</td>
      <td>1.78</td>
      <td>0.53</td>
      <td>0.00</td>
      <td>0.08</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>14244</th>
      <td>NaN</td>
      <td>GEN</td>
      <td>1993.0</td>
      <td>NaN</td>
      <td>0.00</td>
      <td>0.00</td>
      <td>0.03</td>
      <td>0.00</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
  </tbody>
</table>
</div>




```python
df[df['Year_of_Release'].isna()]
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Name</th>
      <th>Platform</th>
      <th>Year_of_Release</th>
      <th>Genre</th>
      <th>NA_sales</th>
      <th>EU_sales</th>
      <th>JP_sales</th>
      <th>Other_sales</th>
      <th>Critic_Score</th>
      <th>User_Score</th>
      <th>Rating</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>183</th>
      <td>Madden NFL 2004</td>
      <td>PS2</td>
      <td>NaN</td>
      <td>Sports</td>
      <td>4.26</td>
      <td>0.26</td>
      <td>0.01</td>
      <td>0.71</td>
      <td>94.0</td>
      <td>8.5</td>
      <td>E</td>
    </tr>
    <tr>
      <th>377</th>
      <td>FIFA Soccer 2004</td>
      <td>PS2</td>
      <td>NaN</td>
      <td>Sports</td>
      <td>0.59</td>
      <td>2.36</td>
      <td>0.04</td>
      <td>0.51</td>
      <td>84.0</td>
      <td>6.4</td>
      <td>E</td>
    </tr>
    <tr>
      <th>456</th>
      <td>LEGO Batman: The Videogame</td>
      <td>Wii</td>
      <td>NaN</td>
      <td>Action</td>
      <td>1.80</td>
      <td>0.97</td>
      <td>0.00</td>
      <td>0.29</td>
      <td>74.0</td>
      <td>7.9</td>
      <td>E10+</td>
    </tr>
    <tr>
      <th>475</th>
      <td>wwe Smackdown vs. Raw 2006</td>
      <td>PS2</td>
      <td>NaN</td>
      <td>Fighting</td>
      <td>1.57</td>
      <td>1.02</td>
      <td>0.00</td>
      <td>0.41</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>609</th>
      <td>Space Invaders</td>
      <td>2600</td>
      <td>NaN</td>
      <td>Shooter</td>
      <td>2.36</td>
      <td>0.14</td>
      <td>0.00</td>
      <td>0.03</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <th>16373</th>
      <td>PDC World Championship Darts 2008</td>
      <td>PSP</td>
      <td>NaN</td>
      <td>Sports</td>
      <td>0.01</td>
      <td>0.00</td>
      <td>0.00</td>
      <td>0.00</td>
      <td>43.0</td>
      <td>tbd</td>
      <td>E10+</td>
    </tr>
    <tr>
      <th>16405</th>
      <td>Freaky Flyers</td>
      <td>GC</td>
      <td>NaN</td>
      <td>Racing</td>
      <td>0.01</td>
      <td>0.00</td>
      <td>0.00</td>
      <td>0.00</td>
      <td>69.0</td>
      <td>6.5</td>
      <td>T</td>
    </tr>
    <tr>
      <th>16448</th>
      <td>Inversion</td>
      <td>PC</td>
      <td>NaN</td>
      <td>Shooter</td>
      <td>0.01</td>
      <td>0.00</td>
      <td>0.00</td>
      <td>0.00</td>
      <td>59.0</td>
      <td>6.7</td>
      <td>M</td>
    </tr>
    <tr>
      <th>16458</th>
      <td>Hakuouki: Shinsengumi Kitan</td>
      <td>PS3</td>
      <td>NaN</td>
      <td>Adventure</td>
      <td>0.01</td>
      <td>0.00</td>
      <td>0.00</td>
      <td>0.00</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>16522</th>
      <td>Virtua Quest</td>
      <td>GC</td>
      <td>NaN</td>
      <td>Role-Playing</td>
      <td>0.01</td>
      <td>0.00</td>
      <td>0.00</td>
      <td>0.00</td>
      <td>55.0</td>
      <td>5.5</td>
      <td>T</td>
    </tr>
  </tbody>
</table>
<p>269 rows × 11 columns</p>
</div>




```python
df[df['Genre'].isna()]
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Name</th>
      <th>Platform</th>
      <th>Year_of_Release</th>
      <th>Genre</th>
      <th>NA_sales</th>
      <th>EU_sales</th>
      <th>JP_sales</th>
      <th>Other_sales</th>
      <th>Critic_Score</th>
      <th>User_Score</th>
      <th>Rating</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>659</th>
      <td>NaN</td>
      <td>GEN</td>
      <td>1993.0</td>
      <td>NaN</td>
      <td>1.78</td>
      <td>0.53</td>
      <td>0.00</td>
      <td>0.08</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>14244</th>
      <td>NaN</td>
      <td>GEN</td>
      <td>1993.0</td>
      <td>NaN</td>
      <td>0.00</td>
      <td>0.00</td>
      <td>0.03</td>
      <td>0.00</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
  </tbody>
</table>
</div>




```python
df[df['Critic_Score'].isna()]
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Name</th>
      <th>Platform</th>
      <th>Year_of_Release</th>
      <th>Genre</th>
      <th>NA_sales</th>
      <th>EU_sales</th>
      <th>JP_sales</th>
      <th>Other_sales</th>
      <th>Critic_Score</th>
      <th>User_Score</th>
      <th>Rating</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>1</th>
      <td>Super Mario Bros.</td>
      <td>NES</td>
      <td>1985.0</td>
      <td>Platform</td>
      <td>29.08</td>
      <td>3.58</td>
      <td>6.81</td>
      <td>0.77</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>4</th>
      <td>Pokemon Red/Pokemon Blue</td>
      <td>GB</td>
      <td>1996.0</td>
      <td>Role-Playing</td>
      <td>11.27</td>
      <td>8.89</td>
      <td>10.22</td>
      <td>1.00</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>5</th>
      <td>Tetris</td>
      <td>GB</td>
      <td>1989.0</td>
      <td>Puzzle</td>
      <td>23.20</td>
      <td>2.26</td>
      <td>4.22</td>
      <td>0.58</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>9</th>
      <td>Duck Hunt</td>
      <td>NES</td>
      <td>1984.0</td>
      <td>Shooter</td>
      <td>26.93</td>
      <td>0.63</td>
      <td>0.28</td>
      <td>0.47</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>10</th>
      <td>Nintendogs</td>
      <td>DS</td>
      <td>2005.0</td>
      <td>Simulation</td>
      <td>9.05</td>
      <td>10.95</td>
      <td>1.93</td>
      <td>2.74</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <th>16710</th>
      <td>Samurai Warriors: Sanada Maru</td>
      <td>PS3</td>
      <td>2016.0</td>
      <td>Action</td>
      <td>0.00</td>
      <td>0.00</td>
      <td>0.01</td>
      <td>0.00</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>16711</th>
      <td>LMA Manager 2007</td>
      <td>X360</td>
      <td>2006.0</td>
      <td>Sports</td>
      <td>0.00</td>
      <td>0.01</td>
      <td>0.00</td>
      <td>0.00</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>16712</th>
      <td>Haitaka no Psychedelica</td>
      <td>PSV</td>
      <td>2016.0</td>
      <td>Adventure</td>
      <td>0.00</td>
      <td>0.00</td>
      <td>0.01</td>
      <td>0.00</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>16713</th>
      <td>Spirits &amp; Spells</td>
      <td>GBA</td>
      <td>2003.0</td>
      <td>Platform</td>
      <td>0.01</td>
      <td>0.00</td>
      <td>0.00</td>
      <td>0.00</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>16714</th>
      <td>Winning Post 8 2016</td>
      <td>PSV</td>
      <td>2016.0</td>
      <td>Simulation</td>
      <td>0.00</td>
      <td>0.00</td>
      <td>0.01</td>
      <td>0.00</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
  </tbody>
</table>
<p>8578 rows × 11 columns</p>
</div>




```python
df[df['User_Score'].isna()]
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Name</th>
      <th>Platform</th>
      <th>Year_of_Release</th>
      <th>Genre</th>
      <th>NA_sales</th>
      <th>EU_sales</th>
      <th>JP_sales</th>
      <th>Other_sales</th>
      <th>Critic_Score</th>
      <th>User_Score</th>
      <th>Rating</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>1</th>
      <td>Super Mario Bros.</td>
      <td>NES</td>
      <td>1985.0</td>
      <td>Platform</td>
      <td>29.08</td>
      <td>3.58</td>
      <td>6.81</td>
      <td>0.77</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>4</th>
      <td>Pokemon Red/Pokemon Blue</td>
      <td>GB</td>
      <td>1996.0</td>
      <td>Role-Playing</td>
      <td>11.27</td>
      <td>8.89</td>
      <td>10.22</td>
      <td>1.00</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>5</th>
      <td>Tetris</td>
      <td>GB</td>
      <td>1989.0</td>
      <td>Puzzle</td>
      <td>23.20</td>
      <td>2.26</td>
      <td>4.22</td>
      <td>0.58</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>9</th>
      <td>Duck Hunt</td>
      <td>NES</td>
      <td>1984.0</td>
      <td>Shooter</td>
      <td>26.93</td>
      <td>0.63</td>
      <td>0.28</td>
      <td>0.47</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>10</th>
      <td>Nintendogs</td>
      <td>DS</td>
      <td>2005.0</td>
      <td>Simulation</td>
      <td>9.05</td>
      <td>10.95</td>
      <td>1.93</td>
      <td>2.74</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <th>16710</th>
      <td>Samurai Warriors: Sanada Maru</td>
      <td>PS3</td>
      <td>2016.0</td>
      <td>Action</td>
      <td>0.00</td>
      <td>0.00</td>
      <td>0.01</td>
      <td>0.00</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>16711</th>
      <td>LMA Manager 2007</td>
      <td>X360</td>
      <td>2006.0</td>
      <td>Sports</td>
      <td>0.00</td>
      <td>0.01</td>
      <td>0.00</td>
      <td>0.00</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>16712</th>
      <td>Haitaka no Psychedelica</td>
      <td>PSV</td>
      <td>2016.0</td>
      <td>Adventure</td>
      <td>0.00</td>
      <td>0.00</td>
      <td>0.01</td>
      <td>0.00</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>16713</th>
      <td>Spirits &amp; Spells</td>
      <td>GBA</td>
      <td>2003.0</td>
      <td>Platform</td>
      <td>0.01</td>
      <td>0.00</td>
      <td>0.00</td>
      <td>0.00</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>16714</th>
      <td>Winning Post 8 2016</td>
      <td>PSV</td>
      <td>2016.0</td>
      <td>Simulation</td>
      <td>0.00</td>
      <td>0.00</td>
      <td>0.01</td>
      <td>0.00</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
  </tbody>
</table>
<p>6701 rows × 11 columns</p>
</div>




```python
df[df['Rating'].isna()]
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Name</th>
      <th>Platform</th>
      <th>Year_of_Release</th>
      <th>Genre</th>
      <th>NA_sales</th>
      <th>EU_sales</th>
      <th>JP_sales</th>
      <th>Other_sales</th>
      <th>Critic_Score</th>
      <th>User_Score</th>
      <th>Rating</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>1</th>
      <td>Super Mario Bros.</td>
      <td>NES</td>
      <td>1985.0</td>
      <td>Platform</td>
      <td>29.08</td>
      <td>3.58</td>
      <td>6.81</td>
      <td>0.77</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>4</th>
      <td>Pokemon Red/Pokemon Blue</td>
      <td>GB</td>
      <td>1996.0</td>
      <td>Role-Playing</td>
      <td>11.27</td>
      <td>8.89</td>
      <td>10.22</td>
      <td>1.00</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>5</th>
      <td>Tetris</td>
      <td>GB</td>
      <td>1989.0</td>
      <td>Puzzle</td>
      <td>23.20</td>
      <td>2.26</td>
      <td>4.22</td>
      <td>0.58</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>9</th>
      <td>Duck Hunt</td>
      <td>NES</td>
      <td>1984.0</td>
      <td>Shooter</td>
      <td>26.93</td>
      <td>0.63</td>
      <td>0.28</td>
      <td>0.47</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>10</th>
      <td>Nintendogs</td>
      <td>DS</td>
      <td>2005.0</td>
      <td>Simulation</td>
      <td>9.05</td>
      <td>10.95</td>
      <td>1.93</td>
      <td>2.74</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <th>16710</th>
      <td>Samurai Warriors: Sanada Maru</td>
      <td>PS3</td>
      <td>2016.0</td>
      <td>Action</td>
      <td>0.00</td>
      <td>0.00</td>
      <td>0.01</td>
      <td>0.00</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>16711</th>
      <td>LMA Manager 2007</td>
      <td>X360</td>
      <td>2006.0</td>
      <td>Sports</td>
      <td>0.00</td>
      <td>0.01</td>
      <td>0.00</td>
      <td>0.00</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>16712</th>
      <td>Haitaka no Psychedelica</td>
      <td>PSV</td>
      <td>2016.0</td>
      <td>Adventure</td>
      <td>0.00</td>
      <td>0.00</td>
      <td>0.01</td>
      <td>0.00</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>16713</th>
      <td>Spirits &amp; Spells</td>
      <td>GBA</td>
      <td>2003.0</td>
      <td>Platform</td>
      <td>0.01</td>
      <td>0.00</td>
      <td>0.00</td>
      <td>0.00</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>16714</th>
      <td>Winning Post 8 2016</td>
      <td>PSV</td>
      <td>2016.0</td>
      <td>Simulation</td>
      <td>0.00</td>
      <td>0.00</td>
      <td>0.01</td>
      <td>0.00</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
  </tbody>
</table>
<p>6766 rows × 11 columns</p>
</div>



# Выводы:

<div style="border:solid blue 2px; padding: 20px"> 
    
Названия столбцов в датафрейме записаны в верхнем регистре.

Категориальные переменные: Name, Platform, Genre, Rating.
Количественные переменные: Year_of_Release, NA_sales, EU_sales, JP_sales, Other_sales, Critic_Score, User_Score.

В данных присутствуют пропуски в столбцах: Name, Year_of_Release, Genre, Critic_Score, User_Score, Rating. Большое количество значений NaN в трех последних столбцах.

Тип данных был определен неверно в следующих столбцах: Year_of_release, User_score.

Также в столбце User_score были обнаружены некорректные значения 'tbd', а в столбцах Name, Genre и Year_of_Release были обнаружены дубликаты.

Данные требуют предварительной обработки.
<\div>

# Шаг 3. Подготовьте данные

Привожу названия столбцов к нижнему регистру.


```python
df.columns = df.columns.str.lower()

print(df.head())
```

                           name platform  year_of_release         genre  na_sales  \
    0                Wii Sports      Wii           2006.0        Sports     41.36   
    1         Super Mario Bros.      NES           1985.0      Platform     29.08   
    2            Mario Kart Wii      Wii           2008.0        Racing     15.68   
    3         Wii Sports Resort      Wii           2009.0        Sports     15.61   
    4  Pokemon Red/Pokemon Blue       GB           1996.0  Role-Playing     11.27   
    
       eu_sales  jp_sales  other_sales  critic_score user_score rating  
    0     28.96      3.77         8.45          76.0          8      E  
    1      3.58      6.81         0.77           NaN        NaN    NaN  
    2     12.76      3.79         3.29          82.0        8.3      E  
    3     10.93      3.28         2.95          80.0          8      E  
    4      8.89     10.22         1.00           NaN        NaN    NaN  
    

Преобразую данные в нужные типы в столбцах Year_of_release (float64, а должен быть int64, т.к год - это целое число), User_score (object, а должен быть float64, т.к. оценка пользователей - это количественная переменная). 

Прежде, чем поменять тип в столбце User_score, необходимо убрать значения 'tbd'. Для этого я использую параметр 'errors ='coerce' метода to_numeric, который принудительно заменит некорректные значения на NaN. Это позволит не удалять строки и продолжить работу с Датафреймом


```python
df['user_score'] = pd.to_numeric(df['user_score'], errors='coerce')
```

Данные в строках с NaN не стоит заменять на 0, т.к. это может привести к некорректным результатам статистического анализа. Удалять строки с пустыми данными во всех колонках, на мой взгляд, также нельзя. Данные отсутствуют в своем большистве всего лишь в 3 столбцах, а в 8 - они полноценные. Удалив такое кол-во строк, мы сильно исказим информацию, например, о данных по продажам или платформе.

Поэтому почистим строки только в 3х колонках с именем, жанром и годом релиза, т.к. строки без этих данных нам не пригодятся в анализе и восстановить их нельзя. Из 16715 строк удалим 271, т.е 2% от общего количества.


```python
df.dropna(subset=['name', 'genre', 'year_of_release'], inplace=True)
df['year_of_release'] = df['year_of_release'].astype(np.int64)
df.info()
```

    <class 'pandas.core.frame.DataFrame'>
    Int64Index: 16444 entries, 0 to 16714
    Data columns (total 11 columns):
     #   Column           Non-Null Count  Dtype  
    ---  ------           --------------  -----  
     0   name             16444 non-null  object 
     1   platform         16444 non-null  object 
     2   year_of_release  16444 non-null  int64  
     3   genre            16444 non-null  object 
     4   na_sales         16444 non-null  float64
     5   eu_sales         16444 non-null  float64
     6   jp_sales         16444 non-null  float64
     7   other_sales      16444 non-null  float64
     8   critic_score     7983 non-null   float64
     9   user_score       7463 non-null   float64
     10  rating           9768 non-null   object 
    dtypes: float64(6), int64(1), object(4)
    memory usage: 1.5+ MB
    

В столбце rating отсутствуют данные в 6 769 строках.
ESRB часто повторяет один и тот же тип оценки для одинаковых жанров. Попробую восстановить данные в этом столбце, используя популярный ESRB рейтинг в жанре. Для этого необходимо определить самой популярную оценку для жанра и составить словарь.


```python
genre_list = df['genre'].unique()
genre_dict = {}
for genre in genre_list:
    print(genre)
    rating_value_counts = df[df['genre'] == genre]['rating'].value_counts()
    print(rating_value_counts)
    genre_dict[genre] = rating_value_counts.index[0]
    
genre_dict
```

    Sports
    E       1162
    T        195
    E10+     105
    M         16
    Name: rating, dtype: int64
    Platform
    E       354
    E10+    141
    T        63
    M         3
    Name: rating, dtype: int64
    Racing
    E       576
    T       167
    E10+     95
    M        18
    Name: rating, dtype: int64
    Role-Playing
    T       415
    M       161
    E10+    111
    E        83
    Name: rating, dtype: int64
    Puzzle
    E       284
    E10+     42
    T        10
    Name: rating, dtype: int64
    Misc
    E       449
    T       228
    E10+    166
    M        13
    EC        5
    K-A       1
    Name: rating, dtype: int64
    Shooter
    M       553
    T       340
    E10+     56
    E        47
    Name: rating, dtype: int64
    Simulation
    E       321
    T       186
    E10+     47
    M         5
    Name: rating, dtype: int64
    Action
    T       670
    M       596
    E10+    468
    E       410
    EC        1
    AO        1
    Name: rating, dtype: int64
    Fighting
    T       357
    M        48
    E10+     19
    E         8
    Name: rating, dtype: int64
    Adventure
    E       159
    T       114
    M        98
    E10+     67
    EC        2
    Name: rating, dtype: int64
    Strategy
    T       160
    E10+     76
    E        68
    M        25
    K-A       2
    RP        1
    Name: rating, dtype: int64
    




    {'Sports': 'E',
     'Platform': 'E',
     'Racing': 'E',
     'Role-Playing': 'T',
     'Puzzle': 'E',
     'Misc': 'E',
     'Shooter': 'M',
     'Simulation': 'E',
     'Action': 'T',
     'Fighting': 'T',
     'Adventure': 'E',
     'Strategy': 'T'}




```python
df['rating'] = df['rating'].fillna('NR')

def fill_rating(row):
    if row[10] == 'NR':
        row[10] = genre_dict[row[3]]
    return row

df = df.apply(fill_rating, axis=1)
df.info()
```

    <class 'pandas.core.frame.DataFrame'>
    Int64Index: 16444 entries, 0 to 16714
    Data columns (total 11 columns):
     #   Column           Non-Null Count  Dtype  
    ---  ------           --------------  -----  
     0   name             16444 non-null  object 
     1   platform         16444 non-null  object 
     2   year_of_release  16444 non-null  int64  
     3   genre            16444 non-null  object 
     4   na_sales         16444 non-null  float64
     5   eu_sales         16444 non-null  float64
     6   jp_sales         16444 non-null  float64
     7   other_sales      16444 non-null  float64
     8   critic_score     7983 non-null   float64
     9   user_score       7463 non-null   float64
     10  rating           16444 non-null  object 
    dtypes: float64(6), int64(1), object(4)
    memory usage: 1.5+ MB
    


```python
df['rating'].value_counts()
```




    E       7679
    T       5523
    M       1836
    E10+    1393
    EC         8
    K-A        3
    AO         1
    RP         1
    Name: rating, dtype: int64



Посчитаю суммарные продажи во всех регионах и добавлю их в отдельный столбец total_sales.


```python
df['total_sales'] = df['na_sales'] + df['eu_sales'] + df['jp_sales'] + df['other_sales']
print(df.head())
```

                           name platform  year_of_release         genre  na_sales  \
    0                Wii Sports      Wii             2006        Sports     41.36   
    1         Super Mario Bros.      NES             1985      Platform     29.08   
    2            Mario Kart Wii      Wii             2008        Racing     15.68   
    3         Wii Sports Resort      Wii             2009        Sports     15.61   
    4  Pokemon Red/Pokemon Blue       GB             1996  Role-Playing     11.27   
    
       eu_sales  jp_sales  other_sales  critic_score  user_score rating  \
    0     28.96      3.77         8.45          76.0         8.0      E   
    1      3.58      6.81         0.77           NaN         NaN      E   
    2     12.76      3.79         3.29          82.0         8.3      E   
    3     10.93      3.28         2.95          80.0         8.0      E   
    4      8.89     10.22         1.00           NaN         NaN      T   
    
       total_sales  
    0        82.54  
    1        40.24  
    2        35.52  
    3        32.77  
    4        31.38  
    

# Выводы:

<div style="border:solid blue 2px; padding: 20px"> 
Данные подготовлены к исследовательскому анализу:

1) Названия столбцов приведены к нижнему регистру;

2) Восстановлены пропуски в строках;

3) Удалено минимальное кол-во строк, где отсутствовали необходимые данные для анализа;

4) Добавлен столбец суммарных продаж.

    
</div>

# Шаг 4. Проведите исследовательский анализ данных

<b> Вопрос 1.</b> *Посмотрите, сколько игр выпускалось в разные годы. Важны ли данные за все периоды?*


```python
df_by_year = df.pivot_table(index = 'year_of_release', values = 'name', aggfunc = 'count')
df_by_year.plot(kind='bar', figsize=(8, 8))
```




    <AxesSubplot:xlabel='year_of_release'>




    
![png](output_32_1.png)
    


<div style="border:solid blue 2px; padding: 20px"> 
<b>Вывод:</b> 
С 1980 по 1993 гг. было мало компаний и выпускалось мало игр. Объем выпуска игр начинает активно расти с 1994 года. Наибольшее количество игр было выпущено с 2008 по 2009 гг. Далее с 2010 года объем выпуска игр начал снижаться. 

Задача исследования "выявить определяющие успешность игры закономерности", поэтому для нас будут малоинформативны данные с 1980 по 1993 гг. Т.к. в тот период была низкая конкуренция, и игровая индустрия не была так развита.
    
</div>

<b> Вопрос 2.</b> *Посмотрите, как менялись продажи по платформам. Выберите платформы с наибольшими суммарными продажами и постройте распределение по годам. Найдите популярные в прошлом платформы, у которых сейчас продажи на нуле. За какой характерный период появляются новые и исчезают старые платформы?*


```python
platform_grouped = df.pivot_table(index='platform', values='total_sales', aggfunc='sum').sort_values(
    by='total_sales', ascending=False)
platform_grouped = platform_grouped.head(6).reset_index()
platform_grouped.plot( x='platform', y='total_sales', kind='bar', figsize=(8, 9))
top_platforms_dict = platform_grouped['platform'].unique() #создадим словарь наиболее прибыльных платформ
platform_grouped.describe()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>total_sales</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>count</th>
      <td>6.000000</td>
    </tr>
    <tr>
      <th>mean</th>
      <td>924.613333</td>
    </tr>
    <tr>
      <th>std</th>
      <td>174.136778</td>
    </tr>
    <tr>
      <th>min</th>
      <td>727.580000</td>
    </tr>
    <tr>
      <th>25%</th>
      <td>824.880000</td>
    </tr>
    <tr>
      <th>50%</th>
      <td>911.260000</td>
    </tr>
    <tr>
      <th>75%</th>
      <td>953.765000</td>
    </tr>
    <tr>
      <th>max</th>
      <td>1233.560000</td>
    </tr>
  </tbody>
</table>
</div>




    
![png](output_35_1.png)
    



```python
#распределение продаж по годам для наиболее прибыльных платформ

for platform in top_platforms_dict:
    df[df['platform'] == platform].pivot_table(index='year_of_release', values='total_sales', aggfunc= 'sum').plot(kind='bar', figsize=(10,5))
    plt.title(platform)
```


    
![png](output_36_0.png)
    



    
![png](output_36_1.png)
    



    
![png](output_36_2.png)
    



    
![png](output_36_3.png)
    



    
![png](output_36_4.png)
    



    
![png](output_36_5.png)
    


<div style="border:solid blue 2px; padding: 20px"> 
<b>Вывод:</b> 
Самые прибыльные по суммарным продажам оказались платформы: PS2, X360, PS3, Wii, DS, PS. У 
этих же платформ к 2016 году практически нулевые продажи, т.к. их сменили новые поколения, например, платформы PS2 и PS3 сменила PS4. Из графиков видим, что срок жизни популярных игр в среднем составляет около 10 лет. 
    
</div>

<b> Вопрос 3.</b> *Определите, данные за какой период нужно взять, чтобы исключить значимое искажение распределения по платформам в 2016 году.
Далее работайте только с данными, которые вы определили. Не учитывайте данные за предыдущие годы.*


```python
actual_data = df.query('year_of_release > 2012')
actual_data.head().sort_values(by='year_of_release')
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>name</th>
      <th>platform</th>
      <th>year_of_release</th>
      <th>genre</th>
      <th>na_sales</th>
      <th>eu_sales</th>
      <th>jp_sales</th>
      <th>other_sales</th>
      <th>critic_score</th>
      <th>user_score</th>
      <th>rating</th>
      <th>total_sales</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>16</th>
      <td>Grand Theft Auto V</td>
      <td>PS3</td>
      <td>2013</td>
      <td>Action</td>
      <td>7.02</td>
      <td>9.09</td>
      <td>0.98</td>
      <td>3.96</td>
      <td>97.0</td>
      <td>8.2</td>
      <td>M</td>
      <td>21.05</td>
    </tr>
    <tr>
      <th>23</th>
      <td>Grand Theft Auto V</td>
      <td>X360</td>
      <td>2013</td>
      <td>Action</td>
      <td>9.66</td>
      <td>5.14</td>
      <td>0.06</td>
      <td>1.41</td>
      <td>97.0</td>
      <td>8.1</td>
      <td>M</td>
      <td>16.27</td>
    </tr>
    <tr>
      <th>33</th>
      <td>Pokemon X/Pokemon Y</td>
      <td>3DS</td>
      <td>2013</td>
      <td>Role-Playing</td>
      <td>5.28</td>
      <td>4.19</td>
      <td>4.35</td>
      <td>0.78</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>T</td>
      <td>14.60</td>
    </tr>
    <tr>
      <th>42</th>
      <td>Grand Theft Auto V</td>
      <td>PS4</td>
      <td>2014</td>
      <td>Action</td>
      <td>3.96</td>
      <td>6.31</td>
      <td>0.38</td>
      <td>1.97</td>
      <td>97.0</td>
      <td>8.3</td>
      <td>M</td>
      <td>12.62</td>
    </tr>
    <tr>
      <th>31</th>
      <td>Call of Duty: Black Ops 3</td>
      <td>PS4</td>
      <td>2015</td>
      <td>Shooter</td>
      <td>6.03</td>
      <td>5.86</td>
      <td>0.36</td>
      <td>2.38</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>M</td>
      <td>14.63</td>
    </tr>
  </tbody>
</table>
</div>



<div style="border:solid blue 2px; padding: 20px"> 
<b>Вывод:</b> Можно предположить, что в 2012 произошел кризис (почти в половину снизилось кол-во выпускаемых игр), или смена парадигмы в производстве игр. Упор сменился с объема выпускаемых игр на их качество. Поэтому актуальным периодом для дальнейшего анализа считаю 2013 - 2016 год.
    
</div>

<b> Вопрос 4.</b> *Какие платформы лидируют по продажам, растут или падают? Выберите несколько потенциально прибыльных платформ.*


```python
platform_sales = actual_data.pivot_table(index='platform', values='total_sales', aggfunc='sum').sort_values(
    by='total_sales', ascending=False).plot(kind='bar', figsize=(8, 9))
```


    
![png](output_42_0.png)
    



```python
platform_sales_by_year = actual_data.pivot_table(index='year_of_release', columns = 'platform', values='total_sales',
                                        aggfunc='sum').plot(kind='bar', figsize=(10,10), style=dict)
```


    
![png](output_43_0.png)
    


<div style="border:solid blue 2px; padding: 20px">
<b>Вывод:</b>
По продажам лидируют платформы: PS4, PS3, XOne, X360 и 3DS. Их суммарный доход за 3 года около 1 миллиарда долларов.

Продажи растут у PS4, XOne, 3DS, WiiU и PSV, так как они заменяют предыдущее поколение игровых приставок. На убыль идут приставки предыдущего поколения PS3, X360, DS, Wii и PSP.
    
</div>

<b> Вопрос 5.</b> *Постройте график «ящик с усами» по глобальным продажам каждой игры и разбивкой по платформам. Велика ли разница в продажах? А в средних продажах на разных платформах? Опишите результат.*


```python
actual_data.boxplot(column = 'total_sales')
plt.ylim(0,1,25)
actual_data['total_sales'].describe()
```




    count    2233.000000
    mean        0.488442
    std         1.235226
    min         0.010000
    25%         0.030000
    50%         0.110000
    75%         0.400000
    max        21.050000
    Name: total_sales, dtype: float64




    
![png](output_46_1.png)
    



```python
PS4_actual_data = actual_data.query('platform =="PS4"')
PS4_actual_data.boxplot(column = 'total_sales')
PS4_actual_data['total_sales'].describe()
```




    count    392.000000
    mean       0.801378
    std        1.609456
    min        0.010000
    25%        0.060000
    50%        0.200000
    75%        0.730000
    max       14.630000
    Name: total_sales, dtype: float64




    
![png](output_47_1.png)
    



```python
PS3_actual_data = actual_data.query('platform =="PS3"')
PS3_actual_data.boxplot(column = 'total_sales')
PS3_actual_data['total_sales'].describe()
```




    count    345.000000
    mean       0.525884
    std        1.451939
    min        0.010000
    25%        0.040000
    50%        0.150000
    75%        0.510000
    max       21.050000
    Name: total_sales, dtype: float64




    
![png](output_48_1.png)
    



```python
XOne_actual_data = actual_data.query('platform =="XOne"')
XOne_actual_data.boxplot(column = 'total_sales')
XOne_actual_data['total_sales'].describe()
```




    count    247.000000
    mean       0.645020
    std        1.036139
    min        0.010000
    25%        0.060000
    50%        0.220000
    75%        0.685000
    max        7.390000
    Name: total_sales, dtype: float64




    
![png](output_49_1.png)
    



```python
X360_actual_data = actual_data.query('platform =="X360"')
X360_actual_data.boxplot(column = 'total_sales')
X360_actual_data['total_sales'].describe()
```




    count    186.000000
    mean       0.735484
    std        1.663275
    min        0.010000
    25%        0.080000
    50%        0.265000
    75%        0.795000
    max       16.270000
    Name: total_sales, dtype: float64




    
![png](output_50_1.png)
    



```python
_3DS_actual_data = actual_data.query('platform =="3DS"')
_3DS_actual_data.boxplot(column = 'total_sales')
_3DS_actual_data['total_sales'].describe()
```




    count    303.000000
    mean       0.472772
    std        1.381347
    min        0.010000
    25%        0.040000
    50%        0.090000
    75%        0.280000
    max       14.600000
    Name: total_sales, dtype: float64




    
![png](output_51_1.png)
    


<div style="border:solid blue 2px; padding: 20px"> 
<b>Вывод:</b> 
Разница в продажах существенная. Есть очень популярные игры, которые продаются долгое время и дают много прибыли. А есть много игр, которые не смогли преодолеть порог в 400 тыс. долларов за выбранный период.

Средние продажи на игру по миру: 488 тыс. дол. 3/4 игр в диапазоне до 400 тыс. Максимум 21 млн.

Средние продажи на игру по платформе PS4: 801 тыс. 3/4 игр в диапазоне до 730 тыс. Максимум 14,6 млн.

Средние продажи на игру по платформе PS3: 526 тыс. 3/4 игр в диапазоне до 510 тыс. Максимум 21 млн.

Средние продажи на игру по платформе XOne: 645 тыс. 3/4 игр в диапазоне до 685 тыс. Максимум 7,4 млн.

Средние продажи на игру по платформе X360: 735 тыс. 3/4 игр в диапазоне до 795 тыс. Максимум 16,3 млн.

Средние продажи на игру по платформе 3DS: 472 тыс. 3/4 игр в диапазоне до 280 тыс. Максимум 14,6 млн.

Положительная тенденция к росту продаж у платформ PS4, PS3 и 3DS. Они имеют средние продажи больше 3го квантиля, это говорит о том, что у этих платформ более популярные и продаваемые игры, чем на XOne и X360.
</div>

<b> Вопрос 6.</b> *Посмотрите, как влияют на продажи внутри одной популярной платформы отзывы пользователей и критиков. Постройте диаграмму рассеяния и посчитайте корреляцию между отзывами и продажами. Сформулируйте выводы и соотнесите их с продажами игр на других платформах.*


```python
PS4_sales_crit_and_user_ratings = PS4_actual_data.loc[:,['total_sales', 'critic_score', 'user_score']]
PS4_sales_crit_and_user_ratings.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>total_sales</th>
      <th>critic_score</th>
      <th>user_score</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>31</th>
      <td>14.63</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>42</th>
      <td>12.62</td>
      <td>97.0</td>
      <td>8.3</td>
    </tr>
    <tr>
      <th>77</th>
      <td>8.58</td>
      <td>82.0</td>
      <td>4.3</td>
    </tr>
    <tr>
      <th>87</th>
      <td>7.98</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>92</th>
      <td>7.66</td>
      <td>83.0</td>
      <td>5.7</td>
    </tr>
  </tbody>
</table>
</div>




```python
pd.plotting.scatter_matrix(PS4_sales_crit_and_user_ratings, figsize=(12, 12))
```




    array([[<AxesSubplot:xlabel='total_sales', ylabel='total_sales'>,
            <AxesSubplot:xlabel='critic_score', ylabel='total_sales'>,
            <AxesSubplot:xlabel='user_score', ylabel='total_sales'>],
           [<AxesSubplot:xlabel='total_sales', ylabel='critic_score'>,
            <AxesSubplot:xlabel='critic_score', ylabel='critic_score'>,
            <AxesSubplot:xlabel='user_score', ylabel='critic_score'>],
           [<AxesSubplot:xlabel='total_sales', ylabel='user_score'>,
            <AxesSubplot:xlabel='critic_score', ylabel='user_score'>,
            <AxesSubplot:xlabel='user_score', ylabel='user_score'>]],
          dtype=object)




    
![png](output_55_1.png)
    



```python
PS4_sales_crit_and_user_ratings.corr()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>total_sales</th>
      <th>critic_score</th>
      <th>user_score</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>total_sales</th>
      <td>1.000000</td>
      <td>0.406568</td>
      <td>-0.031957</td>
    </tr>
    <tr>
      <th>critic_score</th>
      <td>0.406568</td>
      <td>1.000000</td>
      <td>0.557654</td>
    </tr>
    <tr>
      <th>user_score</th>
      <td>-0.031957</td>
      <td>0.557654</td>
      <td>1.000000</td>
    </tr>
  </tbody>
</table>
</div>




```python
PS3_sales_crit_and_user_ratings = PS3_actual_data.loc[:,['total_sales', 'critic_score', 'user_score']]
PS3_sales_crit_and_user_ratings.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>total_sales</th>
      <th>critic_score</th>
      <th>user_score</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>16</th>
      <td>21.05</td>
      <td>97.0</td>
      <td>8.2</td>
    </tr>
    <tr>
      <th>69</th>
      <td>9.36</td>
      <td>71.0</td>
      <td>2.6</td>
    </tr>
    <tr>
      <th>126</th>
      <td>6.46</td>
      <td>86.0</td>
      <td>4.3</td>
    </tr>
    <tr>
      <th>149</th>
      <td>5.86</td>
      <td>95.0</td>
      <td>9.1</td>
    </tr>
    <tr>
      <th>180</th>
      <td>5.27</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
  </tbody>
</table>
</div>




```python
pd.plotting.scatter_matrix(PS3_sales_crit_and_user_ratings, figsize=(12, 12))
```




    array([[<AxesSubplot:xlabel='total_sales', ylabel='total_sales'>,
            <AxesSubplot:xlabel='critic_score', ylabel='total_sales'>,
            <AxesSubplot:xlabel='user_score', ylabel='total_sales'>],
           [<AxesSubplot:xlabel='total_sales', ylabel='critic_score'>,
            <AxesSubplot:xlabel='critic_score', ylabel='critic_score'>,
            <AxesSubplot:xlabel='user_score', ylabel='critic_score'>],
           [<AxesSubplot:xlabel='total_sales', ylabel='user_score'>,
            <AxesSubplot:xlabel='critic_score', ylabel='user_score'>,
            <AxesSubplot:xlabel='user_score', ylabel='user_score'>]],
          dtype=object)




    
![png](output_58_1.png)
    



```python
PS3_sales_crit_and_user_ratings.corr()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>total_sales</th>
      <th>critic_score</th>
      <th>user_score</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>total_sales</th>
      <td>1.000000</td>
      <td>0.334285</td>
      <td>0.002394</td>
    </tr>
    <tr>
      <th>critic_score</th>
      <td>0.334285</td>
      <td>1.000000</td>
      <td>0.599920</td>
    </tr>
    <tr>
      <th>user_score</th>
      <td>0.002394</td>
      <td>0.599920</td>
      <td>1.000000</td>
    </tr>
  </tbody>
</table>
</div>




```python
XOne_sales_crit_and_user_ratings = XOne_actual_data.loc[:,['total_sales', 'critic_score', 'user_score']]
XOne_sales_crit_and_user_ratings.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>total_sales</th>
      <th>critic_score</th>
      <th>user_score</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>99</th>
      <td>7.39</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>165</th>
      <td>5.47</td>
      <td>97.0</td>
      <td>7.9</td>
    </tr>
    <tr>
      <th>179</th>
      <td>5.26</td>
      <td>81.0</td>
      <td>5.4</td>
    </tr>
    <tr>
      <th>242</th>
      <td>4.49</td>
      <td>84.0</td>
      <td>6.4</td>
    </tr>
    <tr>
      <th>270</th>
      <td>4.22</td>
      <td>88.0</td>
      <td>6.2</td>
    </tr>
  </tbody>
</table>
</div>




```python
pd.plotting.scatter_matrix(XOne_sales_crit_and_user_ratings, figsize=(12, 12))
```




    array([[<AxesSubplot:xlabel='total_sales', ylabel='total_sales'>,
            <AxesSubplot:xlabel='critic_score', ylabel='total_sales'>,
            <AxesSubplot:xlabel='user_score', ylabel='total_sales'>],
           [<AxesSubplot:xlabel='total_sales', ylabel='critic_score'>,
            <AxesSubplot:xlabel='critic_score', ylabel='critic_score'>,
            <AxesSubplot:xlabel='user_score', ylabel='critic_score'>],
           [<AxesSubplot:xlabel='total_sales', ylabel='user_score'>,
            <AxesSubplot:xlabel='critic_score', ylabel='user_score'>,
            <AxesSubplot:xlabel='user_score', ylabel='user_score'>]],
          dtype=object)




    
![png](output_61_1.png)
    



```python
XOne_sales_crit_and_user_ratings.corr()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>total_sales</th>
      <th>critic_score</th>
      <th>user_score</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>total_sales</th>
      <td>1.000000</td>
      <td>0.416998</td>
      <td>-0.068925</td>
    </tr>
    <tr>
      <th>critic_score</th>
      <td>0.416998</td>
      <td>1.000000</td>
      <td>0.472462</td>
    </tr>
    <tr>
      <th>user_score</th>
      <td>-0.068925</td>
      <td>0.472462</td>
      <td>1.000000</td>
    </tr>
  </tbody>
</table>
</div>




```python
_3DS_sales_crit_and_user_ratings = _3DS_actual_data.loc[:,['total_sales', 'critic_score', 'user_score']]
_3DS_sales_crit_and_user_ratings.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>total_sales</th>
      <th>critic_score</th>
      <th>user_score</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>33</th>
      <td>14.60</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>47</th>
      <td>11.68</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>96</th>
      <td>7.55</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>108</th>
      <td>7.14</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>184</th>
      <td>5.22</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
  </tbody>
</table>
</div>




```python
pd.plotting.scatter_matrix(_3DS_sales_crit_and_user_ratings, figsize=(12, 12))
```




    array([[<AxesSubplot:xlabel='total_sales', ylabel='total_sales'>,
            <AxesSubplot:xlabel='critic_score', ylabel='total_sales'>,
            <AxesSubplot:xlabel='user_score', ylabel='total_sales'>],
           [<AxesSubplot:xlabel='total_sales', ylabel='critic_score'>,
            <AxesSubplot:xlabel='critic_score', ylabel='critic_score'>,
            <AxesSubplot:xlabel='user_score', ylabel='critic_score'>],
           [<AxesSubplot:xlabel='total_sales', ylabel='user_score'>,
            <AxesSubplot:xlabel='critic_score', ylabel='user_score'>,
            <AxesSubplot:xlabel='user_score', ylabel='user_score'>]],
          dtype=object)




    
![png](output_64_1.png)
    



```python
_3DS_sales_crit_and_user_ratings.corr()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>total_sales</th>
      <th>critic_score</th>
      <th>user_score</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>total_sales</th>
      <td>1.000000</td>
      <td>0.357057</td>
      <td>0.241504</td>
    </tr>
    <tr>
      <th>critic_score</th>
      <td>0.357057</td>
      <td>1.000000</td>
      <td>0.769536</td>
    </tr>
    <tr>
      <th>user_score</th>
      <td>0.241504</td>
      <td>0.769536</td>
      <td>1.000000</td>
    </tr>
  </tbody>
</table>
</div>




```python
X360_sales_crit_and_user_ratings = X360_actual_data.loc[:,['total_sales', 'critic_score', 'user_score']]
X360_sales_crit_and_user_ratings.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>total_sales</th>
      <th>critic_score</th>
      <th>user_score</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>23</th>
      <td>16.27</td>
      <td>97.0</td>
      <td>8.1</td>
    </tr>
    <tr>
      <th>60</th>
      <td>10.24</td>
      <td>73.0</td>
      <td>2.6</td>
    </tr>
    <tr>
      <th>72</th>
      <td>9.18</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>263</th>
      <td>4.28</td>
      <td>NaN</td>
      <td>4.9</td>
    </tr>
    <tr>
      <th>271</th>
      <td>4.22</td>
      <td>84.0</td>
      <td>4.2</td>
    </tr>
  </tbody>
</table>
</div>




```python
pd.plotting.scatter_matrix(X360_sales_crit_and_user_ratings, figsize=(12, 12))
```




    array([[<AxesSubplot:xlabel='total_sales', ylabel='total_sales'>,
            <AxesSubplot:xlabel='critic_score', ylabel='total_sales'>,
            <AxesSubplot:xlabel='user_score', ylabel='total_sales'>],
           [<AxesSubplot:xlabel='total_sales', ylabel='critic_score'>,
            <AxesSubplot:xlabel='critic_score', ylabel='critic_score'>,
            <AxesSubplot:xlabel='user_score', ylabel='critic_score'>],
           [<AxesSubplot:xlabel='total_sales', ylabel='user_score'>,
            <AxesSubplot:xlabel='critic_score', ylabel='user_score'>,
            <AxesSubplot:xlabel='user_score', ylabel='user_score'>]],
          dtype=object)




    
![png](output_67_1.png)
    



```python
X360_sales_crit_and_user_ratings.corr()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>total_sales</th>
      <th>critic_score</th>
      <th>user_score</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>total_sales</th>
      <td>1.000000</td>
      <td>0.350345</td>
      <td>-0.011742</td>
    </tr>
    <tr>
      <th>critic_score</th>
      <td>0.350345</td>
      <td>1.000000</td>
      <td>0.520946</td>
    </tr>
    <tr>
      <th>user_score</th>
      <td>-0.011742</td>
      <td>0.520946</td>
      <td>1.000000</td>
    </tr>
  </tbody>
</table>
</div>



<div style="border:solid blue 2px; padding: 20px"> 
<b>Вывод:</b>
Для платформы PS4 есть прямая корреляция между продажами и рейтингом критиков. Можно предположить, что важным критерием для платформы является качество игры. 

Между рейтингом критиков и пользователей еще более сильная корреляция. Исходя из анализа, видим, что рейтинг игры влияет на мнение игроков. То есть, чем выше ценит игру критик, тем выше оценит ее игрок.

Также есть незначительная обратная корреляция между продажами и рейтингом пользователей, значит эти величины не зависят друг от друга. 

Платформы PS3, XOne и X360 имеют похожие связи, как и у PS4.

Можно выделить платфому 3DS, чьи продажи зависят напрямую, хоть и не сильно от рейтинга игроков. Можно предположить, что в данном направлении компания лучше ведет работу по составлению рейтинга для игр и системы отзывов для игроков.

   
</div>

<b> Вопрос 7.</b> *Посмотрите на общее распределение игр по жанрам. Что можно сказать о самых прибыльных жанрах? Выделяются ли жанры с высокими и низкими продажами?*


```python
genre_pvt = actual_data.pivot_table(index='genre', values='total_sales', aggfunc='sum')
genre_pvt.sort_values('total_sales', ascending=False).plot(kind='bar', figsize=(10,10))
```




    <AxesSubplot:xlabel='genre'>




    
![png](output_71_1.png)
    


<div style="border:solid blue 2px; padding: 20px"> 
<b>Вывод:</b>
Самые прибыльные жанры: Action, Shooter, Sports и Role-Playing.

Игрокам больше нравятся активные жанры, основаннные на разнообразии действий ("Стрелялки" и "Боевики"), а также ролевые игры, где участвует много игроков. 

Игры логических жанров в сравнении с играми жанра action практически вообще не пользуются спросом.
</div>

# Шаг 5. Составьте портрет пользователя каждого региона

<b> Вопрос 1.</b> 
*Определите для пользователя каждого региона (NA, EU, JP):*

*- Самые популярные платформы (топ-5). Опишите различия в долях продаж.*


```python
top_5_na_sales = actual_data.query('na_sales > 0').groupby(['platform'], 
            as_index = False)['na_sales'].sum().sort_values('na_sales', 
                                ascending = False).head(5)['platform'].tolist()
 
for name in top_5_na_sales:
    actual_data.query('platform == @name').pivot_table(index = 'year_of_release',
                        values = ['na_sales'], aggfunc = 'sum').sort_values('year_of_release', 
                                                    ascending = False).plot(kind='bar',figsize = (10, 5), title = name)
    
    plt.xlabel('Дата релиза', labelpad = 10)
    plt.ylabel('Продажи', labelpad = 50)
    plt.legend()
```


    
![png](output_75_0.png)
    



    
![png](output_75_1.png)
    



    
![png](output_75_2.png)
    



    
![png](output_75_3.png)
    



    
![png](output_75_4.png)
    



```python
top_5_eu_sales = actual_data.query('eu_sales > 0').groupby(['platform'], 
            as_index = False)['eu_sales'].sum().sort_values('eu_sales', 
                                ascending = False).head(5)['platform'].tolist()
 
for name in top_5_eu_sales:
    actual_data.query('platform == @name').pivot_table(index = 'year_of_release',
                        values = ['eu_sales'], aggfunc = 'sum').sort_values('year_of_release', 
                                                    ascending = False).plot(kind='bar',figsize = (10, 5), title = name)
    
    plt.xlabel('Дата релиза', labelpad = 10)
    plt.ylabel('Продажи', labelpad = 50)
    plt.legend()
```


    
![png](output_76_0.png)
    



    
![png](output_76_1.png)
    



    
![png](output_76_2.png)
    



    
![png](output_76_3.png)
    



    
![png](output_76_4.png)
    



```python
top_5_jp_sales = actual_data.query('jp_sales > 0').groupby(['platform'], 
            as_index = False)['jp_sales'].sum().sort_values('jp_sales', 
                                ascending = False).head(5)['platform'].tolist()
 
for name in top_5_jp_sales:
    actual_data.query('platform == @name').pivot_table(index = 'year_of_release',
                        values = ['jp_sales'], aggfunc = 'sum').sort_values('year_of_release', 
                                                    ascending = False).plot(kind='bar',figsize = (10, 5), title = name)
    
    plt.xlabel('Дата релиза', labelpad = 10)
    plt.ylabel('Продажи', labelpad = 50)
    plt.legend()
```


    
![png](output_77_0.png)
    



    
![png](output_77_1.png)
    



    
![png](output_77_2.png)
    



    
![png](output_77_3.png)
    



    
![png](output_77_4.png)
    


<div style="border:solid blue 2px; padding: 20px"> 
<b>Вывод:</b>
Рейтинг платформ по суммарным продажам в регионе:

Топ 5 по Северной Америке: PS4, XOne, X360, PS3 и 3DS

Топ 5 по Европейскому региону: PS4, PS3, XOne, X360 и 3DS

Топ 5 по Японии: 3DS, PS3, PSV, PS4 и WiiU

Получается, что за выбранный период 2013-2016 гг. по суммарным продажам в регионах есть незначительные различия в предпочтениях пользователей в Америке и Европе. Самые высокие продажи в этих регионах у PS4, платформа XOne по продажам на 2м месте. 

А в Японии PS4 находится на 4м месте, самые высокие суммарные продажи у 3DS (Нинтендо).

Но с разбивкой продаж по годам видна одна общая тенденция по всем регионам, PS4 охватывает все большую долю рынка и ее продажи растут.  У PS3 самые высокие продажи в 2013 году во всех регионах и к 2016  идет активный спад. 

В Америке и Европе к 2016 году продажи растут у XOne,  а вот в Японии на 2м месте PSV.
</div>

<b> Вопрос 2.</b> *- Самые популярные жанры (топ-5). Поясните разницу.*


```python
genre_by_area = actual_data.query('jp_sales > 0 and eu_sales > 0 and na_sales > 0').pivot_table(index='genre', 
    values=['na_sales','eu_sales','jp_sales'], aggfunc='sum').sort_values(by='genre')
print(genre_by_area)
genre_by_area.plot(kind='bar', figsize=(12, 12))
```

                  eu_sales  jp_sales  na_sales
    genre                                     
    Action           78.65     17.80     77.82
    Adventure         3.66      0.91      2.70
    Fighting          5.79      5.49      9.70
    Misc              9.20      4.27     11.52
    Platform         10.15      4.63     11.80
    Puzzle            0.45      0.53      0.59
    Racing           14.99      2.09      9.64
    Role-Playing     29.09     26.70     36.13
    Shooter          66.13      6.49     75.74
    Simulation        3.29      3.36      1.54
    Sports           36.97      2.23     17.47
    Strategy          0.37      0.30      0.58
    




    <AxesSubplot:xlabel='genre'>




    
![png](output_80_2.png)
    


<div style="border:solid blue 2px; padding: 20px"> 
<b>Вывод:</b>
Рейтинг жанров:

Топ 5 по Северной Америке: Action, Shooter, Sports, Role-Playing и Misc

Топ 5 по Европейскому региону: Action, Shooter, Sports, Role-Playing и Racing

Топ 5 по Японии: Role-Playing, Action, Misc, Fighting и Shooter

Как и в выборе платформы, так и в выборе по жанру Америка и Европа солидарны. Япония больше предпочитает ролевые игры, а потом уже экшн. В целом можно отметить, что японские игроманы выбирают более "вдумчивые" жанры.
 </div>

<b> Вопрос 2.</b> *Влияет ли рейтинг ESRB на продажи в отдельном регионе?*


```python
rating_by_area = actual_data.pivot_table(index='rating', values=['na_sales','eu_sales','jp_sales'], 
                aggfunc='sum').sort_values(by='rating')
print(rating_by_area)
rating_by_area.plot(kind='bar', figsize=(12, 12))
```

            eu_sales  jp_sales  na_sales
    rating                              
    E         108.37     33.35    102.09
    E10+       42.69      5.89     54.24
    M         162.21     14.92    184.77
    T          78.96     86.62     96.61
    




    <AxesSubplot:xlabel='rating'>




    
![png](output_83_2.png)
    


<div style="border:solid blue 2px; padding: 20px"> 
<b>Вывод:</b> Рейтинг возраста влияет по каждому региону.

В Америке и Европе схожие ситуации, лучше всего продаются игры с возрастным рейтингом М (17+). Следом идут игры для любого возраста. В Японии же лидируют по продажам игры с рейтингом 13+, также на 2м месте расположились игры с рейтингом Е (для всех возрастов).

</div>

# Шаг 6. Проведите исследование статистических показателей

*Как изменяется пользовательский рейтинг и рейтинг критиков в различных жанрах? Посчитайте среднее количество, дисперсию и стандартное отклонение. Опишите распределения.*


```python
genre_critic_score = actual_data.query('critic_score > 0').groupby(['genre'], 
            as_index = False)['critic_score'].sum().sort_values('critic_score', 
                                ascending = False).head(10)['genre'].tolist()
 
for name in genre_critic_score:
    actual_data.query('genre == @name').pivot_table(index = 'year_of_release',
                        values = ['critic_score'], aggfunc = ['sum', 'count','mean']).sort_values('year_of_release', 
                                                    ascending = False).plot(kind='bar',figsize = (10, 5), title = name)
    
    plt.xlabel('Год', labelpad = 10)
    plt.ylabel('Рейтинг критиков', labelpad = 50)
    plt.legend()
```


    
![png](output_87_0.png)
    



    
![png](output_87_1.png)
    



    
![png](output_87_2.png)
    



    
![png](output_87_3.png)
    



    
![png](output_87_4.png)
    



    
![png](output_87_5.png)
    



    
![png](output_87_6.png)
    



    
![png](output_87_7.png)
    



    
![png](output_87_8.png)
    



    
![png](output_87_9.png)
    



```python
genre_user_score = actual_data.query('user_score > 0').groupby(['genre'], 
            as_index = False)['user_score'].sum().sort_values('user_score', 
                                ascending = False).head(10)['genre'].tolist()
 
for name in genre_critic_score:
    actual_data.query('genre == @name').pivot_table(index = 'year_of_release',
                        values = ['user_score'], aggfunc = ['sum', 'count','mean']).sort_values('year_of_release', 
                                                    ascending = False).plot(kind='bar',figsize = (10, 5), title = name)
    
    plt.xlabel('Год', labelpad = 10)
    plt.ylabel('Рейтинг пользователей', labelpad = 50)
    plt.legend()
```


    
![png](output_88_0.png)
    



    
![png](output_88_1.png)
    



    
![png](output_88_2.png)
    



    
![png](output_88_3.png)
    



    
![png](output_88_4.png)
    



    
![png](output_88_5.png)
    



    
![png](output_88_6.png)
    



    
![png](output_88_7.png)
    



    
![png](output_88_8.png)
    



    
![png](output_88_9.png)
    



```python
genre_score = actual_data.pivot_table(index='genre', values=['critic_score','user_score'], 
                aggfunc=['sum', 'count', 'mean']).sort_values(by='genre')
genre_score
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead tr th {
        text-align: left;
    }

    .dataframe thead tr:last-of-type th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr>
      <th></th>
      <th colspan="2" halign="left">sum</th>
      <th colspan="2" halign="left">count</th>
      <th colspan="2" halign="left">mean</th>
    </tr>
    <tr>
      <th></th>
      <th>critic_score</th>
      <th>user_score</th>
      <th>critic_score</th>
      <th>user_score</th>
      <th>critic_score</th>
      <th>user_score</th>
    </tr>
    <tr>
      <th>genre</th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>Action</th>
      <td>22365.0</td>
      <td>2659.8</td>
      <td>313</td>
      <td>389</td>
      <td>71.453674</td>
      <td>6.837532</td>
    </tr>
    <tr>
      <th>Adventure</th>
      <td>3414.0</td>
      <td>447.7</td>
      <td>47</td>
      <td>60</td>
      <td>72.638298</td>
      <td>7.461667</td>
    </tr>
    <tr>
      <th>Fighting</th>
      <td>2923.0</td>
      <td>337.8</td>
      <td>42</td>
      <td>48</td>
      <td>69.595238</td>
      <td>7.037500</td>
    </tr>
    <tr>
      <th>Misc</th>
      <td>3151.0</td>
      <td>362.7</td>
      <td>43</td>
      <td>52</td>
      <td>73.279070</td>
      <td>6.975000</td>
    </tr>
    <tr>
      <th>Platform</th>
      <td>3765.0</td>
      <td>389.4</td>
      <td>51</td>
      <td>58</td>
      <td>73.823529</td>
      <td>6.713793</td>
    </tr>
    <tr>
      <th>Puzzle</th>
      <td>529.0</td>
      <td>52.3</td>
      <td>7</td>
      <td>7</td>
      <td>75.571429</td>
      <td>7.471429</td>
    </tr>
    <tr>
      <th>Racing</th>
      <td>4345.0</td>
      <td>395.2</td>
      <td>61</td>
      <td>65</td>
      <td>71.229508</td>
      <td>6.080000</td>
    </tr>
    <tr>
      <th>Role-Playing</th>
      <td>9331.0</td>
      <td>1003.2</td>
      <td>127</td>
      <td>136</td>
      <td>73.472441</td>
      <td>7.376471</td>
    </tr>
    <tr>
      <th>Shooter</th>
      <td>9771.0</td>
      <td>989.4</td>
      <td>134</td>
      <td>156</td>
      <td>72.917910</td>
      <td>6.342308</td>
    </tr>
    <tr>
      <th>Simulation</th>
      <td>1816.0</td>
      <td>187.7</td>
      <td>28</td>
      <td>31</td>
      <td>64.857143</td>
      <td>6.054839</td>
    </tr>
    <tr>
      <th>Sports</th>
      <td>8026.0</td>
      <td>838.1</td>
      <td>112</td>
      <td>160</td>
      <td>71.660714</td>
      <td>5.238125</td>
    </tr>
    <tr>
      <th>Strategy</th>
      <td>1939.0</td>
      <td>185.5</td>
      <td>26</td>
      <td>30</td>
      <td>74.576923</td>
      <td>6.183333</td>
    </tr>
  </tbody>
</table>
</div>




```python
actual_data.describe()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>year_of_release</th>
      <th>na_sales</th>
      <th>eu_sales</th>
      <th>jp_sales</th>
      <th>other_sales</th>
      <th>critic_score</th>
      <th>user_score</th>
      <th>total_sales</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>count</th>
      <td>2233.000000</td>
      <td>2233.000000</td>
      <td>2233.000000</td>
      <td>2233.000000</td>
      <td>2233.000000</td>
      <td>991.000000</td>
      <td>1192.000000</td>
      <td>2233.000000</td>
    </tr>
    <tr>
      <th>mean</th>
      <td>2014.477385</td>
      <td>0.196019</td>
      <td>0.175652</td>
      <td>0.063045</td>
      <td>0.053726</td>
      <td>72.023209</td>
      <td>6.584564</td>
      <td>0.488442</td>
    </tr>
    <tr>
      <th>std</th>
      <td>1.089439</td>
      <td>0.547730</td>
      <td>0.512451</td>
      <td>0.233997</td>
      <td>0.165693</td>
      <td>12.841318</td>
      <td>1.610413</td>
      <td>1.235226</td>
    </tr>
    <tr>
      <th>min</th>
      <td>2013.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>13.000000</td>
      <td>0.200000</td>
      <td>0.010000</td>
    </tr>
    <tr>
      <th>25%</th>
      <td>2014.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>66.000000</td>
      <td>5.800000</td>
      <td>0.030000</td>
    </tr>
    <tr>
      <th>50%</th>
      <td>2014.000000</td>
      <td>0.020000</td>
      <td>0.030000</td>
      <td>0.010000</td>
      <td>0.010000</td>
      <td>74.000000</td>
      <td>7.000000</td>
      <td>0.110000</td>
    </tr>
    <tr>
      <th>75%</th>
      <td>2015.000000</td>
      <td>0.150000</td>
      <td>0.130000</td>
      <td>0.050000</td>
      <td>0.040000</td>
      <td>81.000000</td>
      <td>7.800000</td>
      <td>0.400000</td>
    </tr>
    <tr>
      <th>max</th>
      <td>2016.000000</td>
      <td>9.660000</td>
      <td>9.090000</td>
      <td>4.350000</td>
      <td>3.960000</td>
      <td>97.000000</td>
      <td>9.300000</td>
      <td>21.050000</td>
    </tr>
  </tbody>
</table>
</div>




```python
actual_data['critic_score'].hist()
```




    <AxesSubplot:>




    
![png](output_91_1.png)
    



```python
actual_data['user_score'].hist()
```




    <AxesSubplot:>




    
![png](output_92_1.png)
    



```python
variance_estimate = np.var(actual_data['user_score'])
print(variance_estimate) 
```

    2.5912550110355372
    


```python
variance_estimate = np.var(actual_data['critic_score'])
print(variance_estimate) 
```

    164.73306376968878
    

<div style="border:solid blue 2px; padding: 20px">
<b>Вывод:</b>
Больше всего оценок, как у критиков, так и у пользователей по играм в наиболее популярных жанрах: Action, Shooter, Sports, Role-Playing. Средняя и медиана практически не отличаются, значит большого разброса по оценкам критиков и пользователей нет. В основном игры оцениваются положительно, по гистограммам видно, что критики чаще ставят оценки в диапазоне от 70 до 80. А пользователи - от 7 до 8. Но в общем сложилось впечатление, что пользователи немного благосклоннее.
    
</div>

# Шаг 7. Проверьте гипотезы

- *Средние пользовательские рейтинги платформ Xbox One и PC одинаковые;*

- *Средние пользовательские рейтинги жанров Action (англ. «действие») и Sports (англ. «виды спорта») разные.*

*Задайте самостоятельно пороговое значение alpha.*


```python
def stat_info(serie, bins=0): #Подготовка данных по первой гипотезе. Исключим игры с пустым рейтингом.
    serie_description = serie.describe()
    mean = serie_description[1]
    std = serie_description[2]
    d_min = serie_description[3]
    q1 = serie_description[4]
    median = serie_description[5]
    q3 = serie_description[6]
    d_max = serie_description[7]
    left_border = d_min
    right_border = d_max
    if bins == 0:
        bins = right_border - left_border
        if bins>100:
            bins = 100
        elif bins < 1:
            bins = abs(bins*10)+1
        bins = int(bins)
    else:
        bins = bins
    serie.hist(bins=bins, range=(left_border, right_border))
    print(serie_description)
    variance_estimate = np.var(serie, ddof=1)
    standart_dev = np.std(serie, ddof=1)
    print('Среднее значение: {:.2f}'.format(mean))
    print('Дисперсия: {:.2f}'.format(variance_estimate))
    print('Стандартное отклонение: {:.2f}'.format(standart_dev))
    return [mean, variance_estimate, standart_dev]
```


```python
user_rating_XOne = actual_data.query('platform == "XOne"')['user_score'].dropna()
stat_info(user_rating_XOne)
```

    count    182.000000
    mean       6.521429
    std        1.380941
    min        1.600000
    25%        5.800000
    50%        6.800000
    75%        7.500000
    max        9.200000
    Name: user_score, dtype: float64
    Среднее значение: 6.52
    Дисперсия: 1.91
    Стандартное отклонение: 1.38
    




    [6.52142857142857, 1.9069968429360702, 1.3809405645921442]




    
![png](output_99_2.png)
    



```python
user_rating_PC = actual_data.query('platform == "PC"')['user_score'].dropna()
stat_info(user_rating_PC)
```

    count    155.000000
    mean       6.269677
    std        1.742381
    min        1.400000
    25%        5.300000
    50%        6.800000
    75%        7.600000
    max        9.300000
    Name: user_score, dtype: float64
    Среднее значение: 6.27
    Дисперсия: 3.04
    Стандартное отклонение: 1.74
    




    [6.269677419354836, 3.035892752408884, 1.7423813452883625]




    
![png](output_100_2.png)
    


<div style="border:solid blue 2px; padding: 20px">
Средние кол-ва значений похожи, дисперсия выборок отличается.

Нулевая гипотеза: "Средние пользовательские рейтинги платформ Xbox One и PC одинаковые".

Альтернативная гипотеза гласит: "Средние пользовательские рейтинги платформ Xbox One и PC различаются".

Для оценки гипотезы необходимо применить тест Стьюдента. 
При получении ответа "Отвергаем нулевую гипотезу", делаю вывод, что данные различаются и нулевая гипотеза неверна.

При получении ответа "Не получилось отвергнуть нулевую гипотезу"- это значит, что нулевая гипотеза подтвердиась.
</div>


```python

alpha = 0.01

results = st.ttest_ind(user_rating_XOne, user_rating_PC)

print('p-значение:', results.pvalue)

if (results.pvalue < alpha):
    print("Отвергаем нулевую гипотезу")
else:
    print("Не получилось отвергнуть нулевую гипотезу")
```

    p-значение: 0.14012658403611647
    Не получилось отвергнуть нулевую гипотезу
    

Подготовим данные для жанров Action и Sports.


```python
user_rating_Action = actual_data.query('genre == "Action"')['user_score'].dropna()
stat_info(user_rating_Action)
```

    count    389.000000
    mean       6.837532
    std        1.330173
    min        2.000000
    25%        6.300000
    50%        7.100000
    75%        7.800000
    max        9.100000
    Name: user_score, dtype: float64
    Среднее значение: 6.84
    Дисперсия: 1.77
    Стандартное отклонение: 1.33
    




    [6.837532133676097, 1.76936090424827, 1.3301732609883083]




    
![png](output_104_2.png)
    



```python
user_rating_Sports = actual_data.query('genre == "Sports"')['user_score'].dropna()
stat_info(user_rating_Sports)
```

    count    160.000000
    mean       5.238125
    std        1.783427
    min        0.200000
    25%        4.100000
    50%        5.500000
    75%        6.500000
    max        8.800000
    Name: user_score, dtype: float64
    Среднее значение: 5.24
    Дисперсия: 3.18
    Стандартное отклонение: 1.78
    




    [5.238124999999999, 3.1806128144654062, 1.783427266379374]




    
![png](output_105_2.png)
    


Нулевая гипотеза: "Средние пользовательские рейтинги жанров Action и Sports одинаковые".

Альтернативная гипотеза: "Средние пользовательские рейтинги жанров Action и Sports различаются".

Для оценки гипотезы также необходимо применить тест Стьюдента. 


```python
alpha = 0.01

results = st.ttest_ind(user_rating_Action, user_rating_Sports)

print('p-значение:', results.pvalue)

if (results.pvalue < alpha):
    print("Отвергаем нулевую гипотезу")
else:
    print("Не получилось отвергнуть нулевую гипотезу")
```

    p-значение: 1.0517832389140023e-27
    Отвергаем нулевую гипотезу
    

<div style="border:solid blue 2px; padding: 20px">
<b>Вывод:</b>
Нулевая гипотеза об одинаковых средних пользовательских рейтингах платформ PC и XOne подтвердилась, это можно было наблюдать при анализе зависимости платформ, рейтинга и суммарных продаж.  Не зря данные платформы возглавляли топ по продажам, пользователи любят данные платформы и оценивают примерно одинаково. 
Нулевая гипотеза о том, что средние пользовательские рейтинги жанров Action и Sports одинаковые была отвергнута. Жанр Action самый популярный среди игроков, в этом жанре выпускается большее кол-во игр. А также из проведенного статистического анализа мы знаем, что средний пользовательский рейтинг жанра Action = 6.837532, а жанра Sports = 5.238125.
    
</div>

# Общий вывод 

<div style="border:solid red 2px; padding: 20px">
В ходе исследования было выполнено:

1) Были изучены данные из файла, выявлены аномалии и пропущенные значения;

2) Проведена подготовка данных (предобработка);

3) Проведен исследовательский анализ данных, который на каждом этапе был подкреплен выводами;

4) Составлен портрет пользователей каждого региона;

5) Проведено исследование статистических показателей; 

6) Выполнена проверка гипотез.

<b>Цель исследования - выявить определяющие успешность игры закономерности.</b>

В ходе анализа были выявлены тенденции развития игровой индустрии, с 2013 года сменилась парадигма выпуска игр с кол-ва на качество. Средняя продолжительность жизни популярной платформы около 10 лет. 

Лидерами среди игровых платформ являются PS4, ХОne для Америки и Европы, а для Японии PS4, PSV и WiiU.

Игровой портрет американских и европейких пользователей отличается от портрета японцев.

Американцы и европейцы выбирают платформы для игр PS4 и XONE, преобладающая целевая аудитория - это люди в возрасте 17+, которые в основном предпочитают игры  в жанрах: Action, Shooter, Sports, Role-Playing.

Японские пользователи выбирают платформы PS4 и PSМ (тенденция на 2016 год), преобладающая целевая аудитория - это подростки 13+, которые в основном предпочитают игры  в жанрах: Role-Playing, Action, Misc, Fighting и Shooter.

Стоит отметить, что в японском регионе отдают предпочтение своим производителям. В Америке и Европе наряду с японским лидером рынка PS4, также популярна "местная" платфома XONE, которая производится компанией Microsoft. 

При прогнозировании затрат на рекламные кампании обязательно нужно учитывать разные целевые аудитории по регионам. 


</div>
